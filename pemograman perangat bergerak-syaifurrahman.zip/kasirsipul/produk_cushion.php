<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk - Cushion | Toko Syaifurrahman</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #ff69b4;
            color: white;
            padding: 15px 30px;
            text-align: center;
        }

        header h1 {
            margin-bottom: 5px;
            font-size: 22px;
        }

        nav a {
            margin-right: 15px;
            color: #ecf0f1;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s, text-shadow 0.3s;
        }

        nav a:hover {
            text-shadow: 1px 1px 5px rgba(255, 255, 255, 0.8);
        }

        .produk-detail {
            padding: 20px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            justify-items: center;
            align-items: start;
            max-width: 1000px;
            margin: 0 auto;
            opacity: 0;
            animation: fadeIn 1.5s ease-in-out forwards;
        }

        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        .produk-item {
            text-align: center;
            width: 100%;
            max-width: 300px;
            opacity: 0;
            transform: translateY(30px);
            animation: slideUp 0.6s ease forwards;
            background-color: white;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            overflow: hidden;
        }

        @keyframes slideUp {
            0% {
                opacity: 0;
                transform: translateY(30px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .produk-item:nth-child(1) { animation-delay: 0.2s; }
        .produk-item:nth-child(2) { animation-delay: 0.4s; }
        .produk-item:nth-child(3) { animation-delay: 0.6s; }
        .produk-item:nth-child(4) { animation-delay: 0.8s; }
        .produk-item:nth-child(5) { animation-delay: 1s; }
        .produk-item:nth-child(6) { animation-delay: 1.2s; }

        .produk-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: transform 0.3s ease;
        }

        .produk-item img:hover {
            transform: scale(1.05);
        }

        .produk-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        .info h2 {
            font-size: 18px;
            color: #333;
            margin-bottom: 8px;
        }

        .info p {
            font-size: 14px;
            color: #555;
            margin-bottom: 10px;
            line-height: 1.6;
        }

        .price {
            font-size: 16px;
            font-weight: bold;
            color: #27ae60;
            margin-top: 10px;
        }

        footer {
            text-align: center;
            padding: 15px;
            background: #ff69b4;
            color: white;
            margin-top: 30px;
        }

        footer p {
            margin: 0;
            font-size: 14px;
        }

        @media screen and (max-width: 768px) {
            header h1 {
                font-size: 18px;
            }

            .info h2 {
                font-size: 16px;
            }

            .info p {
                font-size: 14px;
            }

            .price {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

<header>
    <h1>Toko Syaifurrahman</h1>
    <nav>
        <a href="home.php">Beranda</a>
        <a href="tabel.php">Produk</a>
        <a href="kami.php">Tentang Kami</a>
        <a href="kontak.php">Kontak</a>
    </nav>
</header>

<div class="produk-detail">
    <!-- Produk 1 -->
    <div class="produk-item">
        <img src="pict/cushiong2g.jpeg" alt="Cushion">
        <div class="info">
            <h2>Cushion</h2>
            <p>Cushion dengan formula ringan dan tahan lama, memberikan hasil yang natural dan coverage yang sempurna untuk kulit Anda.</p>
        </div>
    </div>

    <!-- Produk 2 -->
    <div class="produk-item">
        <img src="pict/000(6).jpg" alt="Cushion Shade 00 Affogato">
        <div class="info">
            <h2>Cushion Shade 00 Affogato</h2>
            <p>Untuk kulit putih cerah dengan cool undertoneee.</p>
        </div>
    </div>

    <!-- Produk 3 -->
    <div class="produk-item">
        <img src="pict/cuhion1(6).jpg" alt="Cushion Shade 01 Butter Cream">
        <div class="info">
            <h2>Cushion Shade 01 Butter Cream</h2>
            <p>Cocok untuk kulit putih pink dengan cool undertone.</p>
        </div>
    </div>

    <!-- Produk 4 -->
    <div class="produk-item">
        <img src="pict/cushiong2g.jpeg" alt="Cushion Shade 02 Praline">
        <div class="info">
            <h2>Cushion Shade 02 Praline</h2>
            <p>Cocok untuk kulit kuning langsat dengan neutral undertone.</p>
        </div>
    </div>

    <!-- Produk 5 -->
    <div class="produk-item">
        <img src="pict/tiga(6).jpg" alt="Cushion Shade 03 Custard">
        <div class="info">
            <h2>Cushion Shade 03 Custard</h2>
            <p>Cocok untuk kulit sawo matang terang dengan natural undertone.</p>
        </div>
    </div>

    <!-- Produk 6 -->
    <div class="produk-item">
        <img src="pict/444 (6).jpg" alt="Cushion Shade 04 Gincer">
        <div class="info">
            <h2>Cushion Shade 04 Gincer</h2>
            <p>Cocok untuk kulit sawo matang gelap/tan skin dengan warm undertone.</p>
        </div>
    </div>
</div>

<footer>
    &copy; 2025 Toko Syaifurrahman. All rights reserved.
</footer>

</body>
</html>
