<?php
$host = "localhost";    // atau coba ganti ke "127.0.0.1"
$username = "root";
$password = "";
$dbname = "Syaifurrahman";

$koneksi = mysqli_connect($host, $username, $password, $dbname);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
