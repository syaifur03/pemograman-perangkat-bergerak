<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama  = htmlspecialchars($_POST['nama']);
    $email = htmlspecialchars($_POST['email']);
    $pesan = htmlspecialchars($_POST['pesan']);

    // Simpan ke database, kirim email, atau tampilkan hasil
    echo "<h2>Pesan berhasil dikirim!</h2>";
    echo "<p><strong>Nama:</strong> $nama</p>";
    echo "<p><strong>Email:</strong> $email<
/p>";
    echo "<p><strong>Pesan:</strong><br>$pesan</p>";
} else {
    echo "Form belum dikirim.";
}
?>
