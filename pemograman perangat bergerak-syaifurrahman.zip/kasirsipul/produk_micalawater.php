<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk - Micalawater | Toko Syaifurrahman</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #ff69b4;
            color: white;
            padding: 15px 30px;
            text-align: center;
        }

        header h1 {
            margin-bottom: 5px;
            font-size: 22px;
        }

        nav a {
            margin-right: 15px;
            color: #ecf0f1;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s, text-shadow 0.3s;
        }

        nav a:hover {
            text-shadow: 1px 1px 5px rgba(255, 255, 255, 0.8);
        }

        .produk-detail {
            padding: 20px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            justify-items: center;
            align-items: start;
            max-width: 1000px;
            margin: 0 auto;
            opacity: 0;
            animation: fadeIn 1.5s ease-in-out forwards;
        }

        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        .produk-item {
            text-align: center;
            width: 100%;
            max-width: 300px;
            opacity: 0;
            transform: translateY(30px);
            animation: slideUp 0.6s ease forwards;
            background-color: white;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            overflow: hidden; /* Prevents text and image from spilling over */
        }

        @keyframes slideUp {
            0% {
                opacity: 0;
                transform: translateY(30px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .produk-item:nth-child(1) {
            animation-delay: 0.2s;
        }
        .produk-item:nth-child(2) {
            animation-delay: 0.4s;
        }
        .produk-item:nth-child(3) {
            animation-delay: 0.6s;
        }
        .produk-item:nth-child(4) {
            animation-delay: 0.8s;
        }
        .produk-item:nth-child(5) {
            animation-delay: 1s;
        }

        .produk-detail img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: transform 0.3s ease;
        }

        .produk-detail .info h2 {
            font-size: 18px;
            color: #333;
            margin-bottom: 8px;
        }

        .produk-detail .info p {
            font-size: 14px;
            color: #555;
            margin-bottom: 10px;
            line-height: 1.6;
        }

        .produk-detail .info .price {
            font-size: 16px;
            font-weight: bold;
            color: #27ae60;
            margin-top: 10px;
        }

        .produk-detail img:hover {
            transform: scale(1.05);
        }

        .produk-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        footer {
            text-align: center;
            padding: 15px;
            background: #ff69b4;
            color: white;
            margin-top: 30px;
        }

        footer p {
            margin: 0;
            font-size: 14px;
        }

        /* Media Queries */
        @media screen and (max-width: 768px) {
            header h1 {
                font-size: 18px;
            }

            .produk-detail .info h2 {
                font-size: 16px;
            }

            .produk-detail .info p {
                font-size: 14px;
            }

            .produk-detail .info .price {
                font-size: 14px;
            }
            
        }
    </style>
</head>
<body>

<header>
    <h1>Toko Syaifurrahman</h1>
    <nav>
        <a href="home.php">Beranda</a>
        <a href="tabel.php">Produk</a>
        <a href="kami.php">Tentang Kami</a>
        <a href="kontak.php">Kontak</a>
    </nav>
</header>

<div class="produk-detail">
    <!-- Produk 1 -->
    <div class="produk-item">
        <img src="pict/micalawater.jpg" alt="Micalawater">
        <div class="info">
            <h2>Micalawater</h2>
            <p>Membersihkan wajah secara menyeluruh dengan kandungan bahan yang lembut dan efektif. Cocok untuk semua jenis kulit.</p>
        </div>
    </div>

    <!-- Produk 2 -->
    <div class="produk-item">
        <img src="pict/pinnkkkk (6).jpg" alt="Micalawater Cherry Blossom">
        <div class="info">
            <h2>Micalawater Cherry Blossom</h2>
            <p>Micellar water dengan kandungan Cherry Blossom dan Betaine, terasa menyegarkan kulit dan seringan toner. Membersihkan makeup waterproof dan kotoran dengan sekali usapan, lembut di mata, serta memberikan rasa segar dan lembab, tanpa rasa lengket membersihkan secara merata.</p>
        </div>
    </div>

    <!-- Produk 3 -->
    <div class="produk-item">
        <img src="pict/hijauuuu(6).jpg" alt="Micalawater Mugwort Salicylic Acid Acne Clear">
        <div class="info">
            <h2>Micalawater Mugwort Salicylic Acid Acne Clear</h2>
            <p>Micellar water G2G hijau (Glad2Glow Mugwort Salicylic Acid Acne Clear) adalah micellar water yang diformulasikan untuk membersihkan makeup, kotoran, dan minyak berlebih di wajah, terutama bagi mereka yang memiliki masalah jerawat membersihkan.</p>
        </div>
    </div>

    <!-- Produk 4 -->
    <div class="produk-item">
        <img src="pict/biruu (6).jpg" alt="Micalawater Panthenol">
        <div class="info">
            <h2>Micalawater Panthenol</h2>
            <p>Micellar water yang diformulasikan untuk kulit berjerawat dan berminyak. Produk ini dirancang untuk membersihkan sisa make-up, kotoran, dan minyak berlebih tanpa membuat kulit kering. Cocok untuk kulit sensitif juga bisa memberi secara merata.</p>
        </div>
    </div>

    <!-- Produk 5 -->
    <div class="produk-item">
        <img src="pict/kuning (6).jpg" alt="Micalawater Yuja Vitamin C">
        <div class="info">
            <h2>Micalawater Yuja Vitamin C</h2>
            <p>Micellar water G2G kuning merujuk pada produk micellar water dari Glad2Glow yang mengandung ekstrak mugwort dan salicylic acid, yang diformulasikan khusus untuk kulit berjerawat. Produk ini membantu membersihkan sisa makeup, minyak berlebih.</p>
        </div>
    </div>
</div>

<footer>
    &copy; <?= date('Y') ?> Toko Syaifurrahman. All rights reserved.
</footer>

</body>
</html>
