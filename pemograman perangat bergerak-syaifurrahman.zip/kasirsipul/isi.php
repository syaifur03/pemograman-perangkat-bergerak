<?php
include 'jembatan.php';

mysqli_query($koneksi, "INSERT INTO produk_syaifurrahman (id_produk, nama_produk, foto, harga, stok)
VALUES (NULL, 'sepatu', '', '1300', '10')")
or die(mysqli_error($koneksi));
?>
