<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami | Toko Syaifurrahman</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f8ff; /* Biru muda */
            color: #333;
        }

        header {
            background-color: #1e90ff; /* DodgerBlue */
            color: white;
            padding: 20px 40px;
            text-align: center;
        }

        header h1 {
            margin-bottom: 10px;
        }

        nav {
            margin-top: 10px;
        }

        nav a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s, text-shadow 0.3s;
        }

        nav a:hover {
            text-shadow: 1px 1px 5px rgba(255, 255, 255, 0.8);
        }

        main {
            max-width: 1000px;
            margin: 50px auto 80px;
            padding: 0 20px;
            line-height: 1.7;
            animation: fadeInUp 1s ease-out;
        }

        h2 {
            text-align: center;
            color: #1e90ff;
            margin-bottom: 30px;
        }

        .about-box {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-bottom: 50px;
        }

        footer {
            background-color: #1e90ff;
            color: white;
            text-align: center;
            padding: 20px;
            margin-top: 50px;
            transition: background-color 0.3s ease;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<header>
    <h1>Toko Syaifurrahman</h1>
    <nav>
        <a href="home.php">Beranda</a>
        <a href="tabel.php">Produk</a>
        <a href="kami.php">Tentang Kami</a>
        <a href="kontak.php">Kontak</a>
        <a href="keranjang.php">Keranjang</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<main>
    <div class="about-box">
        <h2>Tentang Kami</h2>
        <p><strong>Glad2Glow (G2G)</strong> adalah brand skincare lokal yang berkomitmen memberikan perawatan kulit terbaik untuk wanita Indonesia yang ingin tampil percaya diri dengan kulit sehat dan bercahaya.</p>
        <p>Sejak berdiri pada tahun 2024, kami menghadirkan produk-produk skincare inovatif yang diformulasikan dengan bahan alami, teruji secara dermatologis, dan aman digunakan untuk berbagai jenis kulit.</p>
        <p>Dari micellar water, toner, serum, moisturizer, hingga sheet mask — semua produk <strong>Glad2Glow</strong> dikembangkan untuk memberikan hasil maksimal dengan harga yang terjangkau.</p>
        <p>Terima kasih telah mempercayai <strong>G2G</strong> sebagai bagian dari rutinitas perawatan kulit Anda. Kami akan terus berkembang dan berinovasi demi kulit sehat dan glowing alami.</p>
    </div>
</main>

<footer>
    &copy; <?php echo date('Y'); ?> Toko Syaifurrahman. All rights reserved.
</footer>

</body>
</html>
