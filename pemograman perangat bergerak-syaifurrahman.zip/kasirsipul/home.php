<?php
session_start();

// Cek apakah user sudah login, jika belum redirect ke login.php
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <title>Beranda | Toko Syaifurrahman</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f8ff;
            color: #333;
        }

        header {
            background-color: #1e90ff;
            color: white;
            padding: 20px 40px;
            text-align: center;
        }

        nav a {
            margin-right: 20px;
            color: #ecf0f1;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s, text-shadow 0.3s;
        }

        nav a:hover {
            text-shadow: 1px 1px 5px rgba(255, 255, 255, 0.8);
        }

        .hero {
            background: url('pict/download (3).jpg') no-repeat center center;
            background-size: 900px;
            height: 300px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: white;
            text-shadow: 5px 1px 3px rgba(0, 0, 0, 0.6);
        }

        .hero h2 {
            font-size: 42px;
            text-align: center;
            background-color: rgba(0, 0, 0, 0.4);
            padding: 20px;
            border-radius: 10px;
        }

        .shop-now-btn {
            display: inline-block;
            background-color: #1e90ff;
            color: white;
            padding: 10px 20px;
            margin-top: 20px;
            border-radius: 30px;
            font-weight: bold;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .shop-now-btn:hover {
            background-color: #1c86ee;
        }

        main {
            padding: 40px;
            animation: fadeInUp 1s ease-out;
        }

        .produk-container {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            justify-content: center;
        }

        .produk-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 250px;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.8s ease-out forwards;
        }

        .produk-card:nth-child(1) { animation-delay: 0.2s; }
        .produk-card:nth-child(2) { animation-delay: 0.4s; }
        .produk-card:nth-child(3) { animation-delay: 0.6s; }
        .produk-card:nth-child(4) { animation-delay: 0.8s; }
        .produk-card:nth-child(5) { animation-delay: 1s; }

        .produk-card:hover {
            transform: translateY(-5px);
        }

        .produk-card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
            transition: transform 0.3s ease, opacity 0.3s ease;
        }

        .produk-card img:hover {
            transform: scale(1.05);
            opacity: 0.95;
        }

        .produk-card .info {
            padding: 15px;
        }

        .produk-card .info h3 {
            font-size: 18px;
            margin-bottom: 8px;
        }

        .produk-card .info p {
            color: #27ae60;
            font-weight: bold;
        }

        footer {
            text-align: center;
            padding: 20px;
            background: #1e90ff;
            color: white;
            margin-top: 40px;
        }

        @media (max-width: 768px) {
            .hero h2 {
                font-size: 30px;
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .produk-link {
            display: block;
            text-decoration: none;
        }

        .promo-banner {
            background: linear-gradient(to right, #1e90ff, #87cefa);
            color: white;
            padding: 25px;
            text-align: center;
        }

        .testimoni {
            background-color: #e6f2ff;
            padding: 40px;
        }

        .testimoni-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .testimoni-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            width: 300px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .whatsapp-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #25d366;
            color: white;
            padding: 12px 18px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: bold;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>

<body>

    <header>
        <h1>Toko Syaifurrahman</h1>
        <nav>
            <a href="home.php">Beranda</a>
            <a href="tabel.php">Produk</a>
            <a href="kami.php">Tentang Kami</a>
            <a href="kontak.php">Kontak</a>
            <a href="keranjang.php">Keranjang</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <section class="hero">
        <h2>Selamat Datang di Toko Syaifurrahman<br>Beli Produk Skincare Terbaik</h2>
        <a href="tabel.php" class="shop-now-btn">Shop Now</a>
    </section>

    <section class="promo-banner">
        <h2>Diskon Spesial Minggu Ini!</h2>
        <p>Dapatkan diskon hingga <strong>30%</strong> untuk produk pilihan. Promo berlaku sampai Minggu!</p>
    </section>

    <main>
        <h2 style="text-align:center; margin-bottom:30px;">Produk Unggulan</h2>
        <div class="produk-container">
            <?php
            $produk = [
                ['nama' => 'Micalawater', 'harga' => 45000, 'gambar' => 'pict/micalawater.jpg', 'link' => 'produk_micalawater.php'],
                ['nama' => 'Cushion', 'harga' => 97000, 'gambar' => 'pict/cushiong2g.jpeg', 'link' => 'produk_cushion.php'],
                ['nama' => 'Moisturizer', 'harga' => 35000, 'gambar' => 'pict/gggg (6).jpg', 'link' => 'produk_moisturizer.php'],
                ['nama' => 'Serum', 'harga' => 35000, 'gambar' => 'pict/serumpink.jpg', 'link' => 'produk_serum.php'],
                ['nama' => 'Masker', 'harga' => 32000, 'gambar' => 'pict/maskerpink.jpg', 'link' => 'produk_masker.php']
            ];

            foreach ($produk as $item): ?>
                <div class="produk-card">
                    <a href="<?= $item['link'] ?>" class="produk-link">
                        <img src="<?= $item['gambar'] ?>" alt="<?= $item['nama'] ?>">
                    </a>
                    <div class="info">
                        <h3><?= $item['nama'] ?></h3>
                        <p>Rp <?= number_format($item['harga'], 0, 0, '.') ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <section class="testimoni">
        <h2 style="text-align:center; margin-bottom:30px;">Apa Kata Mereka?</h2>
        <div class="testimoni-container">
            <div class="testimoni-box">
                <p>"Produk di Toko Syaiful sangat berkualitas! Saya suka banget serum pink-nya."</p>
                <strong>- Lita, Surabaya</strong>
            </div>
            <div class="testimoni-box">
                <p>"Pengiriman cepat dan harga terjangkau. Pasti belanja lagi!"</p>
                <strong>- Anisa, Jakarta</strong>
            </div>
        </div>
    </section>

    <a class="whatsapp-btn" href="https://wa.me/6281234567890" target="_blank">Hubungi Kami</a>

    <footer>
        <p>&copy; 2025 Toko Syaiful . All rights reserved.</p>
    </footer>

</body>
</html>
