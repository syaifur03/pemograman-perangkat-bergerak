<?php
$no=1;

include  "jembatan.php";

$hasil =mysqli_query($koneksi,"SELECT * FROM produk_syaifurrahman");
while ($data = mysqli_fetch_array($hasil))
{
    echo $data [0];
    echo $data[1];
    echo $data[2];
    echo $data[3];
    echo $data[4];
}