<?php
// HARUS DI BARIS PERTAMA tanpa spasi apapun sebelum ini
session_start();

// Cek apakah user sudah login, jika belum redirect ke login.php
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Daftar Produk | Toko Syaifurrahman</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f8ff;
            color: #333;
        }
        header {
            background-color: #1e90ff;
            color: white;
            padding: 20px 40px;
            text-align: center;
        }
        nav a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s, text-shadow 0.3s;
        }
        nav a:hover {
            text-shadow: 1px 1px 5px rgba(255, 255, 255, 0.8);
        }
        .hero {
            text-align: center;
            margin: 30px 0;
            font-size: 20px;
            color: #555;
        }
        .moving-text {
            display: inline-block;
            white-space: nowrap;
            overflow: hidden;
            animation: slideText 10s linear infinite;
        }
        @keyframes slideText {
            0% { transform: translateX(100%); }
            100% { transform: translateX(-100%); }
        }
        .add-button {
            display: inline-block;
            background-color: #1e90ff;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            margin: 30px 0;
            transition: background-color 0.3s;
        }
        .add-button:hover {
            background-color: #1565c0;
        }
        .container {
            text-align: center;
        }
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 30px;
            margin-bottom: 50px;
            padding: 0 30px;
            animation: fadeInUp 1s ease-out;
        }
        .card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            padding: 10px;
            text-align: center;
            opacity: 0;
            transform: translateY(30px);
            animation: fadeInUp 0.8s ease-out forwards;
        }
        .card:nth-child(1) { animation-delay: 0.2s; }
        .card:nth-child(2) { animation-delay: 0.4s; }
        .card:nth-child(3) { animation-delay: 0.6s; }
        .card:nth-child(4) { animation-delay: 0.8s; }
        .card:nth-child(5) { animation-delay: 1s; }
        .card:nth-child(6) { animation-delay: 1.2s; }
        .card:nth-child(7) { animation-delay: 1.4s; }
        .card:nth-child(8) { animation-delay: 1.6s; }
        .card:hover {
            transform: translateY(-8px);
            box-shadow: 0 6px 50px rgba(30, 144, 255, 0.4);
        }
        .card img {
            height: 120px;
            width: 120px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 10px;
            transition: transform 0.3s ease;
        }
        .card img:hover {
            transform: scale(1.1);
        }
        .card .title {
            font-weight: bold;
            margin-bottom: 10px;
            color: #333;
        }
        .card .price {
            color: #1565c0;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .card .stock {
            font-size: 14px;
            color: #555;
            margin-bottom: 15px;
        }
        .card a {
            display: inline-block;
            margin: 5px;
            padding: 8px 14px;
            background-color: #1e90ff;
            color: white;
            border-radius: 5px;
            text-decoration: none;
            font-size: 13px;
            transition: background-color 0.3s;
        }
        .card a:hover {
            background-color: #1565c0;
        }
        .btn-keranjang {
            background-color: #28a745;
        }
        .btn-keranjang:hover {
            background-color: #218838;
        }
        footer {
            background-color: #1e90ff;
            color: white;
            text-align: center;
            padding: 20px;
            margin-top: 40px;
        }
        @media (max-width: 768px) {
            .card img {
                height: 100px;
                width: 100px;
            }
            .add-button {
                width: 100%;
                text-align: center;
            }
            .container {
                align-items: center;
            }
        }
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<header>
    <h1>Toko Syaifurrahman</h1>
    <nav>
        <a href="home.php">Beranda</a>
        <a href="tabel.php">Produk</a>
        <a href="kami.php">Tentang Kami</a>
        <a href="kontak.php">Kontak</a>
        <a href="keranjang.php">Keranjang</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<section class="hero">
    <h2 class="moving-text">Daftar Produk Skincare Glad2Glow Terbaik Dan Terpercaya</h2>
</section>

<div class="container">
    <a href="form_isi.php" class="add-button">+ Tambah Data</a>
</div>

<div class="container" style="text-align: center; margin-bottom: 20px;">
    <form action="" method="GET">
        <input type="text" name="search" placeholder="Cari produk..." style="padding: 10px; width: 400px; border-radius: 5px;">
        <button type="submit" style="padding: 10px 20px; background-color: #1e90ff; color: white; border: none; border-radius: 5px; cursor: pointer;">
            Cari
        </button>
    </form>
</div>

<div class="product-grid">
<?php
include 'jembatan.php'; // koneksi ke database

function rupiah($angka) {
    return "Rp " . number_format($angka, 2, ',', '.');
}

$search = isset($_GET['search']) ? $_GET['search'] : '';

// Query pencarian
$query = "SELECT * FROM produk_syaifurrahman";
if ($search != '') {
    $safe_search = mysqli_real_escape_string($koneksi, $search);
    $query .= " WHERE nama_produk LIKE '%$safe_search%'";
}

$hasil = mysqli_query($koneksi, $query) or die(mysqli_error($koneksi));

while ($data = mysqli_fetch_assoc($hasil)) {
?>
    <div class="card">
        <img src="pict/<?php echo htmlspecialchars($data['foto']); ?>" alt="Gambar Produk">
        <div class="title"><?php echo htmlspecialchars($data['nama_produk']); ?></div>
        <div class="price"><?php echo rupiah($data['harga']); ?></div>
        <div class="stock">Stok: <?php echo (int)$data['stok']; ?></div>

        <div>
            <a href="formedit.php?keranjang=<?php echo (int)$data['id_produk']; ?>">Edit</a>
            <a href="proses_hapus.php?delete=<?php echo (int)$data['id_produk']; ?>" onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a>
        </div>
        <div style="margin-top: 10px;">
            <a class="btn-keranjang" href="keranjang.php?tambah=<?php echo (int)$data['id_produk']; ?>">+ Keranjang</a>
        </div>
    </div>
<?php
}
?>
</div>

<footer>
    &copy; <?= date('Y') ?> Toko Syaifurrahman. All rights reserved.
</footer>

</body>
</html>
