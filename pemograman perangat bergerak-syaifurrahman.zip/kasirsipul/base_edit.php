<?php

$key = $_GET['keranjang'];
include 'jembatan.php';

mysqli_query($koneksi,"UPDATE produk_syaifurrahman SET nama_produk = 'buku'
WHERE id_produk='$key';");
?>
<!--update nm_table SET nm_kolom='Nilai_baru';-->