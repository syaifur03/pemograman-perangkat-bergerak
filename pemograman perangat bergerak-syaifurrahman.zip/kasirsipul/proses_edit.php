
<?php
include 'jembatan.php';

if (isset($_POST['ok'])) {
    $key = $_POST['id'];
    $a = $_POST['nama'];
    $b = $_POST['hrg'];
    $c = $_POST['stk'];

    $folderUpload = __DIR__ . "/pict";

    $fileFoto = (object) @$_FILES['foto'];

    $uploadFotoSukses = false;
    if (!empty($fileFoto->tmp_name)) {
        $uploadFotoSukses = move_uploaded_file($fileFoto->tmp_name, "{$folderUpload}/{$fileFoto->name}");
    }

    if (empty($fileFoto->name)) {
        mysqli_query($koneksi, "UPDATE produk_syaifurrahman SET nama_produk='$a', harga='$b', stok='$c' WHERE id_produk='$key';");
    } else {
        mysqli_query($koneksi, "UPDATE produk_syaifurrahman SET nama_produk='$a', foto='$fileFoto->name', harga='$b', stok='$c' WHERE id_produk='$key';");
    }

    echo "<script>alert('Produk berhasil diperbarui');document.location='tabel.php'</script>";
}
?>
