<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk - Moisturizer | Toko Syaifurrahman</title>
   <style>
    body {
        font-family: 'Segoe UI', sans-serif;
        background-color: #f5f5f5;
        color: #333;
        margin: 0;
        padding: 0;
    }

    header {
        background-color: #ff69b4;
        color: white;
        padding: 20px 40px;
        text-align: center;
    }

    header h1 {
        margin-bottom: 10px;
    }

    nav a {
        margin-right: 20px;
        color: #ecf0f1;
        text-decoration: none;
        font-weight: bold;
        transition: color 0.3s, text-shadow 0.3s;
    }

    nav a:hover {
        text-shadow: 1px 1px 5px rgba(255, 255, 255, 0.8);
    }

    .produk-detail {
        padding: 40px;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 30px 50px; /* jarak baris 40px, kolom 30px */
        justify-items: center;
        align-items: start;
        max-width: 1200px;
        margin: 0 auto;
        opacity: 0;
        animation: fadeIn 1.5s ease-in-out forwards;
    }

    @keyframes fadeIn {
        0% { opacity: 0; }
        100% { opacity: 1; }
    }

    @keyframes slideUp {
        0% {
            opacity: 0;
            transform: translateY(30px);
        }
        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .produk-item {
        background-color: white;
        border: 2px solid #e0e0e0;
        border-radius: 8px;
        padding: 10px;
        text-align: center;
        width: 100%;
        max-width: 400px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        opacity: 0;
        transform: translateY(30px);
        animation: slideUp 0.6s ease forwards;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
        box-sizing: border-box;
        margin: auto;

    }

    .produk-item:nth-child(1) { animation-delay: 0.2s; }
    .produk-item:nth-child(2) { animation-delay: 0.4s; }
    .produk-item:nth-child(3) { animation-delay: 0.6s; }
    .produk-item:nth-child(4) { animation-delay: 0.8s; }
    .produk-item:nth-child(5) { animation-delay: 1s; }
    .produk-item:nth-child(6) { animation-delay: 1.2s; }

    .produk-item:hover {
        transform: translateY(-10px);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
    }

    .produk-item img {
        width: 100%;
        height: 250px;
        object-fit: cover;
        border-radius: 8px;
        margin-bottom: 15px;
        transition: transform 0.3s ease;
    }

    .produk-item img:hover {
        transform: scale(1.05);
    }

    .info h2 {
        font-size: 18px;
        color: #333;
        margin-bottom: 8px;
    }

    .info p {
        font-size: 14px;
        color: #555;
        line-height: 1.6;
        margin-bottom: 10px;
    }

    .price {
        font-size: 16px;
        font-weight: bold;
        color: #27ae60;
        margin-top: 10px;
    }

    footer {
        text-align: center;
        padding: 20px;
        background: #ff69b4;
        color: white;
        margin-top: 40px;
    }

    @media screen and (max-width: 768px) {
        header h1 {
            font-size: 18px;
        }

        .info h2 {
            font-size: 16px;
        }

        .info p {
            font-size: 13px;
        }

        .price {
            font-size: 14px;
        }



    }
</style>

</head>
<body>

<header>
    <h1>Toko Syaifurrahman</h1>
    <nav>
        <a href="home.php">Beranda</a>
        <a href="tabel.php">Produk</a>
        <a href="kami.php">Tentang Kami</a>
        <a href="kontak.php">Kontak</a>
    </nav>
</header>

<div class="produk-detail">
    <!-- Produk 1 -->
    <div class="produk-item">
        <img src="pict/gggg (6).jpg" alt="Moisturizer">
        <div class="info">
            <h2>Moisturizer</h2>
            <p>Memberikan kelembapan yang tahan lama dengan kandungan yang ringan dan cepat meresap di kulit, membuat kulit terasa lebih halus dan lembut.</p>
        </div>
    </div>

    <!-- Produk 2 -->
    <div class="produk-item">
        <img src="pict/moispink.jpg" alt="Brightening Moisturizer">
        <div class="info">
            <h2>Brightening Moisturizer</h2>
            <p>Moisturizer dengan pomegranate & 5% niacinamide, mencerahkan dan meratakan warna kulit. Cocok digunakan pagi dan malam.</p>
        </div>
    </div>

    <!-- Produk 3 -->
    <div class="produk-item">
        <img src="pict/moishijau.jpg" alt="Acne Moisturizer">
        <div class="info">
            <h2>Acne Moisturizer</h2>
            <p>Tekstur gel ringan, mengandung Centella dan Allantoin. Menenangkan kulit berjerawat, mengontrol minyak, dan mengurangi kemerahan.</p>
        </div>
    </div>

    <!-- Produk 4 -->
    <div class="produk-item">
        <img src="pict/moisungu.jpg" alt="Barrier Moisturizer">
        <div class="info">
            <h2>Barrier Moisturizer</h2>
            <p>Mengandung Blueberry & Ceramide 5%, membantu memperbaiki skin barrier dan cocok untuk semua jenis kulit.</p>
        </div>
    </div>

    <!-- Produk 5 -->
    <div class="produk-item">
        <img src="pict/moiscentela.jpg" alt="Centella Moisturizer">
        <div class="info">
            <h2>Centella Moisturizer</h2>
            <p>Centella Allantoin Soothing Gel, meredakan iritasi, memperkuat skin barrier, dan cocok untuk kulit berminyak dan sensitif.</p>
        </div>
    </div>

    <!-- Produk 6 -->
    <div class="produk-item">
        <img src="pict/moisputih.jpg" alt="Dark Spot Moisturizer">
        <div class="info">
            <h2>Dark Spot Moisturizer</h2>
            <p>Dengan Yuja & Symwhite 377 untuk mencerahkan dan menyamarkan bekas jerawat. Mengandung panthenol untuk hidrasi ekstra.</p>
        </div>
    </div>
</div>

<footer>
    &copy; 2025 Toko Syaifurrahman. All rights reserved.
</footer>

</body>
</html>
