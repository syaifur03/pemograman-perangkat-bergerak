<?php
session_start();
include 'jembatan.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

function rupiah($angka) {
    return "Rp " . number_format($angka, 0, ',', '.');
}

if (!isset($_SESSION['keranjang'])) {
    $_SESSION['keranjang'] = [];
}

// Tambah produk ke keranjang
if (isset($_GET['tambah'])) {
    $id = (int)$_GET['tambah'];
    $result = mysqli_query($koneksi, "SELECT * FROM produk_syaifurrahman WHERE id_produk = $id");
    $produk = mysqli_fetch_assoc($result);

    if ($produk && $produk['stok'] > 0) {
        if (isset($_SESSION['keranjang'][$id])) {
            if ($_SESSION['keranjang'][$id] < $produk['stok']) {
                $_SESSION['keranjang'][$id]++;
            } else {
                $_SESSION['error'] = "Stok tidak cukup untuk produk ini.";
            }
        } else {
            $_SESSION['keranjang'][$id] = 1;
        }
    } else {
        $_SESSION['error'] = "Produk tidak ditemukan atau stok habis.";
    }

    header("Location: keranjang.php");
    exit;
}

// Kurangi produk dari keranjang
if (isset($_GET['kurang'])) {
    $id = (int)$_GET['kurang'];
    if (isset($_SESSION['keranjang'][$id])) {
        $_SESSION['keranjang'][$id]--;
        if ($_SESSION['keranjang'][$id] <= 0) {
            unset($_SESSION['keranjang'][$id]);
        }
    }
    header("Location: keranjang.php");
    exit;
}

// Hapus produk dari keranjang
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    unset($_SESSION['keranjang'][$id]);
    header("Location: keranjang.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Keranjang Belanja | Toko Syaifurrahman</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e3f2fd;
            color: #0d47a1;
            margin: 0 auto;
            padding: 20px;
            max-width: 900px;
        }
        h1 {
            text-align: center;
            color: #1565c0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            background-color: white;
            box-shadow: 0 0 10px #90caf9;
        }
        th, td {
            border: 1px solid #bbdefb;
            padding: 12px;
            text-align: center;
        }
        thead {
            background-color: #2196f3;
            color: white;
        }
        tfoot td {
            font-weight: bold;
            background-color: #e3f2fd;
        }
        .btn {
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            margin: 5px;
        }
        .btn-blue {
            background-color: #42a5f5;
            color: white;
        }
        .btn-blue:hover {
            background-color: #1565c0;
        }
        .btn-red {
            background-color: #f44336;
            color: white;
        }
        .btn-red:hover {
            background-color: #d32f2f;
        }
        .nav {
            margin-top: 20px;
        }
        .error {
            background-color: #ffcdd2;
            padding: 10px;
            border: 1px solid #e57373;
            color: #b71c1c;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <h1>Keranjang Belanja</h1>
    <div class="nav">
        <a href="tabel.php" class="btn btn-blue">← Kembali ke Produk</a>
    </div>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <?php if (empty($_SESSION['keranjang'])): ?>
        <p>Keranjang masih kosong.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $total = 0;
                foreach ($_SESSION['keranjang'] as $id_produk => $jumlah):
                    $result = mysqli_query($koneksi, "SELECT * FROM produk_syaifurrahman WHERE id_produk = $id_produk");
                    $produk = mysqli_fetch_assoc($result);
                    $subtotal = $produk['harga'] * $jumlah;
                    $total += $subtotal;
                ?>
                <tr>
                    <td><?= htmlspecialchars($produk['nama_produk']) ?></td>
                    <td><?= rupiah($produk['harga']) ?></td>
                    <td>
                        <a href="?kurang=<?= $id_produk ?>" class="btn btn-blue">-</a>
                        <?= $jumlah ?>
                        <a href="?tambah=<?= $id_produk ?>" class="btn btn-blue">+</a>
                    </td>
                    <td><?= rupiah($subtotal) ?></td>
                    <td><a href="?hapus=<?= $id_produk ?>" class="btn btn-red" onclick="return confirm('Yakin ingin menghapus produk ini?')">Hapus</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" align="right">Total</td>
                    <td colspan="2"><?= rupiah($total) ?></td>
                </tr>
            </tfoot>
        </table>
        <div class="nav">
            <a href="bayar.php" class="btn btn-blue">Lanjut ke Pembayaran</a>
        </div>
    <?php endif; ?>
</body>
</html>
