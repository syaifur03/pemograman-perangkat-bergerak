<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk - Moisturizer | Toko Syaifurrahman</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #ff69b4;
            color: white;
            padding: 20px 40px;
            text-align: center;
        }

        header h1 {
            margin-bottom: 10px;
        }

        nav a {
            margin-right: 20px;
            color: #ecf0f1;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s, text-shadow 0.3s;
        }

        nav a:hover {
            text-shadow: 1px 1px 5px rgba(255, 255, 255, 0.8);
        }

        .produk-detail {
            padding: 40px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
            justify-items: center;
        }

        .produk-item {
            background-color: white;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            width: 100%;
            max-width: 350px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .produk-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        .produk-item img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .info h2 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }

        .info p {
            font-size: 16px;
            color: #555;
            line-height: 1.5;
        }

        .price {
            font-size: 18px;
            font-weight: bold;
            color: #27ae60;
            margin-top: 10px;
        }

        footer {
            text-align: center;
            padding: 20px;
            background: #ff69b4;
            color: white;
            margin-top: 40px;
        }

        @media screen and (max-width: 768px) {
            header h1 {
                font-size: 20px;
            }

            .info h2 {
                font-size: 18px;
            }

            .info p {
                font-size: 14px;
            }

            .price {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>

<header>
    <h1>Toko Syaifurrahman</h1>
    <nav>
        <a href="home.php">Beranda</a>
        <a href="tabel.php">Produk</a>
        <a href="kami.php">Tentang Kami</a>
        <a href="kontak.php">Kontak</a>
    </nav>
</header>

<div class="produk-detail">
    <div class="produk-item">
        <img src="pict/serumpink.jpg" alt="serum">
        <div class="info">
            <h2>Whitening Serum</h2>
            <p>Memberikan kelembapan yang tahan lama dengan kandungan yang ringan dan cepat meresap di kulit, membuat kulit terasa lebih halus dan lembut.</p>
        </div>
    </div>

    
    
    </div>

    <div class="produk-item">
        <img src="pict/serumputih.jpg" alt="Dark Spot Moisturizer">
        <div class="info">
            <h2>Dark Spot Serum</h2>
            <p>Dengan Yuja & Symwhite 377 untuk mencerahkan dan menyamarkan bekas jerawat. Mengandung panthenol untuk hidrasi ekstra.</p>
        </div>
    </div>
</div>

<footer>
    &copy; 2025 Toko Syaifurrahman. All rights reserved.
</footer>

</body>
</html>
