<?php
session_start();
include 'jembatan.php';

function rupiah($angka) {
    return "Rp " . number_format($angka, 2, ',', '.');
}

if (empty($_SESSION['keranjang'])) {
    echo "<p>Keranjang masih kosong. <a href='tabel.php'>Kembali ke Produk</a></p>";
    exit;
}

mysqli_begin_transaction($koneksi);

try {
    $total = 0;

    foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
        $id_produk = (int)$id_produk;
        $jumlah = (int)$jumlah;

        // Lock baris produk supaya aman saat update stok
        $result = mysqli_query($koneksi, "SELECT stok, nama_produk, harga FROM produk_syaifurrahman WHERE id_produk = $id_produk FOR UPDATE");
        if (!$result || mysqli_num_rows($result) == 0) {
            throw new Exception("Produk dengan ID $id_produk tidak ditemukan.");
        }
        $produk = mysqli_fetch_assoc($result);

        if ($produk['stok'] < $jumlah) {
            throw new Exception("Stok produk '{$produk['nama_produk']}' tidak cukup. Stok tersedia: {$produk['stok']}, permintaan: $jumlah.");
        }

        $subtotal = $produk['harga'] * $jumlah;
        $total += $subtotal;

        $new_stok = $produk['stok'] - $jumlah;
        $update = mysqli_query($koneksi, "UPDATE produk_syaifurrahman SET stok = $new_stok WHERE id_produk = $id_produk");
        if (!$update) {
            throw new Exception("Gagal mengupdate stok produk '{$produk['nama_produk']}'.");
        }
    }

    mysqli_commit($koneksi);

    // Kosongkan keranjang setelah berhasil bayar
    $_SESSION['keranjang'] = [];

    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8" />
        <title>Pembayaran Berhasil</title>
        <style>
            body {
                font-family: 'Segoe UI', sans-serif;
                background: #e3f2fd;
                text-align: center;
                padding: 50px;
            }
            .message-box {
                background: white;
                max-width: 500px;
                margin: auto;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            }
            h2 {
                color: #0d47a1;
            }
            p {
                color: #1565c0;
            }
            a.button {
                display: inline-block;
                margin-top: 20px;
                padding: 10px 20px;
                background-color: #2196f3;
                color: white;
                border-radius: 5px;
                text-decoration: none;
                font-weight: 600;
                transition: background-color 0.3s ease;
            }
            a.button:hover {
                background-color: #1565c0;
            }
        </style>
    </head>
    <body>
        <div class="message-box">
            <h2>Pembayaran Berhasil!</h2>
            <p>Terima kasih telah berbelanja di Toko Syaifurrahman.</p>
            <p>Total pembayaran Anda: <strong><?php echo rupiah($total); ?></strong></p>
            <a href="tabel.php" class="button">Kembali ke Produk</a>
        </div>
    </body>
    </html>

    <?php

} catch (Exception $e) {
    mysqli_rollback($koneksi);
    echo "<p style='color:#d32f2f;'>Terjadi kesalahan: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><a href='keranjang.php' style='color:#1565c0;'>Kembali ke Keranjang</a></p>";
}
?>
