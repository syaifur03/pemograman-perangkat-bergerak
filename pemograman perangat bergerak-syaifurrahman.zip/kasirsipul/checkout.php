<?php
session_start();
include 'jembatan.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

if (empty($_SESSION['keranjang'])) {
    echo "Keranjang kosong. <a href='tabel.php'>Kembali</a>";
    exit;
}

$username = $_SESSION['username'];
$total = 0;

// Hitung total harga
foreach ($_SESSION['keranjang'] as $id => $qty) {
    $result = mysqli_query($koneksi, "SELECT harga FROM produk_syaifurrahman WHERE id_produk = $id");
    $data = mysqli_fetch_assoc($result);
    $total += $data['harga'] * $qty;
}

// Simpan transaksi utama
mysqli_query($koneksi, "INSERT INTO transaksi_syaifurrahman (username, total) VALUES ('$username', $total)");
$id_transaksi = mysqli_insert_id($koneksi);

// Simpan detail transaksi dan update stok
foreach ($_SESSION['keranjang'] as $id => $qty) {
    $result = mysqli_query($koneksi, "SELECT harga FROM produk_syaifurrahman WHERE id_produk = $id");
    $data = mysqli_fetch_assoc($result);
    $harga = $data['harga'];

    mysqli_query($koneksi, "INSERT INTO transaksi_detail_syaifurrahman (id_transaksi, id_produk, jumlah, harga) VALUES ($id_transaksi, $id, $qty, $harga)");

    mysqli_query($koneksi, "UPDATE produk_syaifurrahman SET stok = stok - $qty WHERE id_produk = $id");
}

// Pilihan: apakah reset keranjang setelah checkout?
// Jika ingin reset, ubah $reset_keranjang jadi true
// Jika ingin tetap simpan keranjang, ubah jadi false
$reset_keranjang = false;

if ($reset_keranjang) {
    unset($_SESSION['keranjang']);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout Sukses</title>
</head>
<body>
    <h2>Checkout Berhasil!</h2>
    <p>Terima kasih, pesanan Anda telah diproses.</p>
    <a href="keranjang.php">Lihat Keranjang</a> | <a href="tabel.php">Kembali ke Produk</a>
</body>
</html>
