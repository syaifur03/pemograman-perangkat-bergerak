<?php
include "jembatan.php";

if(isset($_POST ['OK']));
    $a = $_POST["nama"];
//    $b = $_POST["gb"];
    $c = $_POST["hrg"];
    $d = $_POST["stk"];

    //echo $a.$b.$c.$d;

$folderUpload = __DIR__ . "/pict";

# periksa apakah folder sudah ada
if (!is_dir($folderUpload)){
    #jika tidak maka folder harus dibuat terlebih dahulu 
    mkdir($folderUpload,0777,$rekursif = true);
}

#simpan masing-masing file ke dalam array
#dan casting menjadi objet :)
$fileFoto = (object) @$_FILES ['foto']; 

#mulai upload file
$uploadFotoSukses = move_uploaded_file($fileFoto->tmp_name,"{$folderUpload}/{$fileFoto->name}");

mysqli_query($koneksi,"INSERT  INTO produk_syaifurrahman
(id_produk, nama_produk, foto, harga, stok)
VALUES
('','$a','$fileFoto->name','$c','$d');")

or die (mysqli_eror($koneksi));


echo "<script>alert('anda sudah menginput 1');document.location='tabel.php'</script>";
?>