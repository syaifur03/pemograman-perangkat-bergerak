<?php
$key = $_GET['delete'];
include 'jembatan.php';

mysqli_query($koneksi,"DELETE FROM PRODUK_syaifurrahman WHERE id_produk='$key';");

?>