<?php


include 'jembatan.php';

if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($koneksi,"DELETE FROM produk_syaifurrahman WHERE id_produk ='$id';");

    echo "<script>alert('anda sudah menghapus');
    document.location='tabel.php';</script>";
}
?>