<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak Kami | Toko Syaifurrahman</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f8ff;
            color: #333;
            transition: background-color 0.3s ease;
        }

        header {
            background-color: #2196f3;
            color: white;
            padding: 20px 40px;
            text-align: center;
            transition: background-color 0.3s ease;
        }

        header h1 {
            margin-bottom: 10px;
            transition: transform 0.3s ease;
        }

        nav {
            margin-top: 10px;
        }

        nav a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease, transform 0.3s ease;
        }

        nav a:hover {
            text-decoration: underline;
            color: #bbdefb;
            transform: scale(1.1);
        }

        main {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            animation: fadeInUp 1s ease-out;
        }

        h2 {
            text-align: center;
            color: #0d47a1;
            margin-bottom: 30px;
            transition: transform 0.3s ease;
        }

        h2:hover {
            transform: scale(1.05);
        }

        .contact-box {
            background-color: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease, transform 0.3s ease;
        }

        .contact-box:hover {
            box-shadow: 0 6px 20px rgba(33, 150, 243, 0.3);
            transform: translateY(-5px);
        }

        .contact-info p {
            margin-bottom: 15px;
            line-height: 1.6;
            transition: color 0.3s ease;
        }

        .contact-info p:hover {
            color: #0d47a1;
        }

        form {
            margin-top: 30px;
            display: flex;
            flex-direction: column;
        }

        input, textarea {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        input:focus, textarea:focus {
            border-color: #2196f3;
            box-shadow: 0 0 5px rgba(33, 150, 243, 0.5);
            outline: none;
        }

        button {
            background-color: #0d47a1;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }

        button:hover {
            background-color: #1565c0;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(33, 150, 243, 0.4);
        }

        footer {
            background-color: #2196f3;
            color: white;
            text-align: center;
            padding: 20px;
            margin-top: 50px;
            transition: background-color 0.3s ease;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        nav a {
            transition: color 0.3s, text-shadow 0.3s;
        }

        nav a:hover {
            text-shadow: 1px 1px 5px rgba(255, 255, 255, 0.8);
        }

        html {
            scroll-behavior: smooth;
        }
    </style>
</head>
<body>

<header>
    <h1>Toko Syaifurrahman</h1>
    <nav>
        <a href="home.php">Beranda</a>
        <a href="tabel.php">Produk</a>
        <a href="kami.php">Tentang Kami</a>
        <a href="kontak.php">Kontak</a>
        <a href="logout.php">Logout</a>
        <a href="keranjang.php">Keranjang</a>
    </nav>
</header>

<main>
    <div class="contact-box">
        <h2>Kontak Kami</h2>
        <div class="contact-info">
            <p><strong>Alamat:</strong> Jl. Teknologi No.123, Jakarta Selatan, Indonesia</p>
            <p><strong>Email:</strong> syaifulrahman370@gmail.com</p>
            <p><strong>Telepon:</strong> 085859540611</p>
            <p><strong>Jam Operasional:</strong> Senin - Jumat, 09.00 - 17.00 WIB</p>
        </div>

        <form id="contactForm">
            <input type="text" name="nama" id="nama" placeholder="Nama Anda" required>
            <input type="email" name="email" id="email" placeholder="Email Anda" required>
            <textarea name="pesan" id="pesan" rows="5" placeholder="Tulis pesan Anda..." required></textarea>
            <button type="submit">Kirim Pesan</button>
        </form>
    </div>
</main>

<footer>
    &copy; <?= date('Y') ?> Toko Syaifurrahman. All rights reserved.
</footer>

<script>
    // Tangani pengiriman formulir
    document.getElementById('contactForm').addEventListener('submit', function(event) {
        event.preventDefault();

        var nama = document.getElementById('nama').value;
        var email = document.getElementById('email').value;
        var pesan = document.getElementById('pesan').value;

        var pesanWhatsApp = "Halo, saya " + encodeURIComponent(nama) + " (" + encodeURIComponent(email) + "). " + encodeURIComponent(pesan);

        var url = "https://wa.me/6287793569049?text=" + pesanWhatsApp;

        window.open(url, '_blank');
    });
</script>

</body>
</html>
